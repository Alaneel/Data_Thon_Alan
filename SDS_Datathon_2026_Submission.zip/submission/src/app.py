"""
🏢 AI-Driven Company Intelligence Dashboard
SDS Datathon 2026 - Champions Group Dataset

This Streamlit dashboard provides interactive visualization and AI-powered
insights for company segmentation analysis.

Features:
- Overview dashboard with key metrics and cluster distribution
- Company search and exploration
- Cluster analysis with LLM-generated personas
- Anomaly detection and investigation
- Company comparison with AI competitive analysis

Usage:
    export GEMINI_API_KEY='your-api-key'
    streamlit run app.py

Author: SDS Datathon 2026 Team
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import os
import sys

# Calculate project root (parent of src/)
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(PROJECT_ROOT, 'data')
MODELS_DIR = os.path.join(PROJECT_ROOT, 'models')

# Add src to path for local imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Page configuration
st.set_page_config(
    page_title="Company Intelligence Dashboard",
    page_icon="🏢",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for dark professional theme
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: 700;
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 1rem;
    }
    .metric-card {
        background: linear-gradient(135deg, #1e1e2e 0%, #2d2d44 100%);
        border-radius: 12px;
        padding: 1.5rem;
        border: 1px solid #3d3d5c;
    }
    .cluster-tag {
        display: inline-block;
        padding: 0.25rem 0.75rem;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
    }
    .cluster-0 { background: #4f46e5; color: white; }
    .cluster-1 { background: #059669; color: white; }
    .cluster-2 { background: #d97706; color: white; }
    .cluster-3 { background: #dc2626; color: white; }
    .anomaly-badge { background: #ef4444; color: white; padding: 0.2rem 0.5rem; border-radius: 8px; }
    .normal-badge { background: #22c55e; color: white; padding: 0.2rem 0.5rem; border-radius: 8px; }
</style>
""", unsafe_allow_html=True)

# Load data
@st.cache_data
def load_data():
    """Load the segmentation results and full dataset"""
    results_df = pd.read_csv(os.path.join(DATA_DIR, 'company_segmentation_results.csv'))
    full_df = pd.read_csv(os.path.join(DATA_DIR, 'champions_group_data.csv'))
    return results_df, full_df

@st.cache_resource
def load_llm():
    """Initialize LLM generator"""
    try:
        from llm_insights import CompanyInsightGenerator
        api_key = os.environ.get('GEMINI_API_KEY')
        if api_key:
            return CompanyInsightGenerator(api_key=api_key)
        return CompanyInsightGenerator()
    except Exception as e:
        st.warning(f"LLM not available: {e}")
        return None

@st.cache_resource
def load_evaluator():
    """Initialize Inference Engine"""
    try:
        from inference_engine import CompanyEvaluator
        return CompanyEvaluator(model_dir=MODELS_DIR)
    except Exception as e:
        st.warning(f"Inference Engine not available: {e}")
        return None

# Load resources
try:
    results_df, full_df = load_data()
    llm = load_llm()
    evaluator = load_evaluator()
except Exception as e:
    st.error(f"Error loading data: {e}")
    st.stop()

# Sidebar
with st.sidebar:
    st.markdown("## 🏢 Company Intelligence")
    st.markdown("---")
    
    # Navigation
    # Navigation
    page = st.radio(
        "📍 Navigation",
        ["📊 Overview", "💰 Lead Scoring", "📋 Due Diligence", "🌏 Market Entry", "🔍 Company Explorer", "📈 Cluster Analysis", "⚠️ Risk Detection", "⚖️ Company Comparison", "🚀 New Company Simulator"],
        index=0
    )
    
    st.markdown("---")
    
    # Filters
    st.markdown("### 🔧 Filters")
    
    # Region filter
    regions = ['All'] + sorted(results_df['Region'].dropna().unique().tolist())
    selected_region = st.selectbox("Region", regions)
    
    # Cluster filter
    clusters = ['All'] + sorted(results_df['Cluster_Name'].dropna().unique().tolist())
    selected_cluster = st.selectbox("Cluster", clusters)
    
    # Anomaly filter
    show_anomalies_only = st.checkbox("Show Anomalies Only", False)
    
    st.markdown("---")
    st.markdown("### 📈 Dataset Stats")
    st.metric("Total Companies", f"{len(results_df):,}")
    st.metric("Clusters", results_df['Cluster'].nunique())
    anomaly_count = (results_df['Anomaly_Label'] == 'Anomaly').sum()
    st.metric("Anomalies", f"{anomaly_count} ({anomaly_count/len(results_df)*100:.1f}%)")

# Apply filters
filtered_df = results_df.copy()
if selected_region != 'All':
    filtered_df = filtered_df[filtered_df['Region'] == selected_region]
if selected_cluster != 'All':
    filtered_df = filtered_df[filtered_df['Cluster_Name'] == selected_cluster]
if show_anomalies_only:
    filtered_df = filtered_df[filtered_df['Anomaly_Label'] == 'Anomaly']

# ============== PAGE: OVERVIEW ==============
if page == "📊 Overview":
    st.markdown('<h1 class="main-header">📊 Company Intelligence Overview</h1>', unsafe_allow_html=True)
    
    
    # Key metrics row
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("📦 Companies in View", f"{len(filtered_df):,}")
    with col2:
        avg_revenue = filtered_df['Revenue_USD_Clean'].mean()
        st.metric("💰 Avg Revenue", f"${avg_revenue/1e6:.2f}M" if avg_revenue > 1e6 else f"${avg_revenue:,.0f}")
    with col3:
        avg_employees = filtered_df['Employees_Total_Clean'].mean()
        st.metric("👥 Avg Employees", f"{avg_employees:,.0f}")
    with col4:
        filtered_anomalies = (filtered_df['Anomaly_Label'] == 'Anomaly').sum()
        st.metric("⚠️ Anomalies", filtered_anomalies)
    
    st.markdown("---")
    
    # Charts row
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### 🎯 Cluster Distribution")
        cluster_counts = filtered_df['Cluster_Name'].value_counts().reset_index()
        cluster_counts.columns = ['Cluster', 'Count']
        
        fig = px.pie(
            cluster_counts, 
            values='Count', 
            names='Cluster',
            color_discrete_sequence=px.colors.qualitative.Set2,
            hole=0.4
        )
        fig.update_layout(
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            font=dict(color='white'),
            showlegend=True,
            legend=dict(orientation='h', yanchor='bottom', y=-0.2)
        )
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.markdown("### 🌍 Regional Distribution")
        region_counts = filtered_df['Region'].value_counts().reset_index()
        region_counts.columns = ['Region', 'Count']
        
        fig = px.bar(
            region_counts,
            x='Region',
            y='Count',
            color='Count',
            color_continuous_scale='Viridis',
            labels={'Region': 'Region', 'Count': 'Number of Companies'}
        )
        fig.update_layout(
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            font=dict(color='white'),
            showlegend=False
        )
        st.plotly_chart(fig, use_container_width=True)
    
    # Revenue vs Employees scatter
    st.markdown("### 💼 Revenue vs Employees by Cluster")
    sample_df = filtered_df.sample(min(1000, len(filtered_df))) if len(filtered_df) > 1000 else filtered_df
    
    fig = px.scatter(
        sample_df,
        x='Employees_Total_Clean',
        y='Revenue_USD_Clean',
        color='Cluster_Name',
        size='Revenue_USD_Clean',
        size_max=30,
        hover_data=['Company Sites', 'SIC Description'],
        log_x=True,
        log_y=True,
        color_discrete_sequence=px.colors.qualitative.Set2,
        labels={
            'Employees_Total_Clean': 'Employees (Total)',
            'Revenue_USD_Clean': 'Revenue (USD)',
            'Cluster_Name': 'Cluster'
        }
    )
    fig.update_layout(
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        font=dict(color='white'),
        height=500
    )
    st.plotly_chart(fig, use_container_width=True)

# ============== PAGE: LEAD SCORING ==============
elif page == "💰 Lead Scoring":
    st.markdown('<h1 class="main-header">💰 B2B Lead Scoring</h1>', unsafe_allow_html=True)
    
    st.markdown("""
    **Business Use Case:** Prioritize sales outreach by scoring companies based on their revenue potential, 
    decision-making power, and data quality. Higher scores indicate higher-value prospects.
    """)
    
    # Check if Lead_Score column exists
    if 'Lead_Score' in filtered_df.columns:
        # Lead tier metrics
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            priority = (filtered_df['Lead_Score'] >= 70).sum()
            st.metric("🔥 Priority Leads", f"{priority:,}", help="Score 70-100")
        with col2:
            hot = ((filtered_df['Lead_Score'] >= 50) & (filtered_df['Lead_Score'] < 70)).sum()
            st.metric("🌡️ Hot Leads", f"{hot:,}", help="Score 50-70")
        with col3:
            warm = ((filtered_df['Lead_Score'] >= 30) & (filtered_df['Lead_Score'] < 50)).sum()
            st.metric("☀️ Warm Leads", f"{warm:,}", help="Score 30-50")
        with col4:
            cold = (filtered_df['Lead_Score'] < 30).sum()
            st.metric("❄️ Cold Leads", f"{cold:,}", help="Score 0-30")
        
        st.markdown("---")
        
        # Lead Score Distribution
        col1, col2 = st.columns(2)
        with col1:
            st.markdown("### 📊 Lead Score Distribution")
            fig = px.histogram(
                filtered_df, x='Lead_Score', nbins=20,
                color_discrete_sequence=['#667eea'],
                labels={'Lead_Score': 'Lead Score', 'count': 'Number of Companies'}
            )
            fig.update_layout(
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                font=dict(color='white')
            )
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            st.markdown("### 🎯 Lead Tier Breakdown")
            tier_counts = filtered_df['Lead_Tier'].value_counts().reset_index()
            tier_counts.columns = ['Tier', 'Count']
            fig = px.pie(
                tier_counts, values='Count', names='Tier',
                color='Tier',
                color_discrete_map={'Priority': '#ef4444', 'Hot': '#f97316', 'Warm': '#eab308', 'Cold': '#3b82f6'}
            )
            fig.update_layout(
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                font=dict(color='white')
            )
            st.plotly_chart(fig, use_container_width=True)
        
        st.markdown("---")
        
        # Top Leads Table
        st.markdown("### 🏆 Top Priority Leads")
        top_leads = filtered_df.nlargest(50, 'Lead_Score')[['Company Sites', 'Country', 'SIC Description', 'Revenue_USD_Clean', 'Employees_Total_Clean', 'Lead_Score', 'Lead_Tier']]
        st.dataframe(top_leads, use_container_width=True, height=400)
        
        # Lead Score Explanation
        with st.expander("ℹ️ How Lead Scores are Calculated (v2 Model)"):
            st.markdown("""
            **Lead Score (0-100)** is calculated based on:
            
            | Factor | Weight | Description |
            |--------|--------|-------------|
            | **Revenue Scale** | 35 pts | >$100M gets max points |
            | **Hierarchy Power** | 20 pts | **Domestic Ultimate** status gets +15 points |
            | **Efficiency & Tech** | 20 pts | High Revenue/Emp & IT Spend |
            | **Market Value** | 15 pts | Publicly traded/Valued bonus |
            | **Stability (Age)** | 10 pts | "Golden Age" (3-10 years) gets max |
            """)
    else:
        st.warning("Lead Score data not available. Please run enhanced_analysis.py first.")

# ============== PAGE: DUE DILIGENCE ==============
elif page == "📋 Due Diligence":
    st.markdown('<h1 class="main-header">📋 AI Due Diligence Report</h1>', unsafe_allow_html=True)
    
    st.markdown("""
    **Business Use Case:** Generate a comprehensive 1-page due diligence summary for any company.
    Designed for risk analysts, M&A teams, and compliance officers.
    """)
    
    # Company selector
    company_list = filtered_df['Company Sites'].dropna().unique().tolist()[:500]
    selected_company = st.selectbox("🏢 Select Company for Due Diligence", company_list, key="dd_company")
    
    if selected_company:
        company_data = filtered_df[filtered_df['Company Sites'] == selected_company].iloc[0]
        
        # Quick preview metrics
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("💰 Revenue", f"${company_data['Revenue_USD_Clean']:,.0f}")
        with col2:
            st.metric("👥 Employees", f"{company_data['Employees_Total_Clean']:,.0f}")
        with col3:
            lead_score = company_data.get('Lead_Score', 0)
            st.metric("⭐ Lead Score", f"{lead_score:.0f}/100")
        with col4:
            risk_flags = company_data.get('Risk_Flags', 0)
            st.metric("⚠️ Risk Flags", f"{risk_flags}")
        
        st.markdown("---")
        
        # Generate Report Button
        if st.button("📋 Generate Full Due Diligence Report", type="primary", use_container_width=True):
            if llm:
                with st.spinner("Generating comprehensive due diligence report..."):
                    # Get industry stats for comparison
                    industry_stats = {
                        "median_revenue": results_df['Revenue_USD_Clean'].median(),
                        "median_productivity": (results_df['Revenue_USD_Clean'] / results_df['Employees_Total_Clean'].replace(0, 1)).median()
                    }
                    
                    report = llm.generate_due_diligence_report(company_data, industry_stats)
                    
                    if "error" in report:
                        st.error(f"Report generation failed: {report['error']}")
                    else:
                        # Store in session state
                        st.session_state.dd_report = report
                        st.rerun()
            else:
                st.warning("LLM is not enabled. Set GEMINI_API_KEY environment variable.")
        
        # Display Report if available
        if "dd_report" in st.session_state and st.session_state.dd_report:
            report = st.session_state.dd_report
            
            # Executive Summary Banner
            verdict = report.get("recommendation", {}).get("verdict", "Unknown")
            verdict_color = "success" if "PROCEED" in verdict and "CAUTION" not in verdict else ("warning" if "CAUTION" in verdict or "REVIEW" in verdict else "error")
            
            if verdict_color == "success":
                st.success(f"**Executive Summary:** {report.get('executive_summary', 'N/A')}")
            elif verdict_color == "warning":
                st.warning(f"**Executive Summary:** {report.get('executive_summary', 'N/A')}")
            else:
                st.error(f"**Executive Summary:** {report.get('executive_summary', 'N/A')}")
            
            st.markdown("---")
            
            # Two-column layout
            col_left, col_right = st.columns(2)
            
            with col_left:
                # Company Profile
                st.markdown("### 🏢 Company Profile")
                profile = report.get("company_profile", {})
                st.markdown(f"""
                | Attribute | Value |
                |-----------|-------|
                | **Name** | {profile.get('name', 'N/A')} |
                | **Industry** | {profile.get('industry', 'N/A')} |
                | **Region** | {profile.get('region', 'N/A')} |
                | **Country** | {profile.get('country', 'N/A')} |
                | **Entity Type** | {profile.get('entity_type', 'N/A')} |
                | **Age** | {profile.get('age', 'N/A')} |
                """)
                
                # Financial Health
                st.markdown("### 📊 Financial Health")
                fin = report.get("financial_health", {})
                
                # Health Grade Badge
                grade = fin.get("health_grade", "N/A")
                grade_colors = {"A": "🟢", "B": "🟢", "C": "🟡", "D": "🟠", "F": "🔴"}
                st.markdown(f"**Grade:** {grade_colors.get(grade, '⚪')} **{grade}**")
                
                st.markdown(f"""
                | Metric | Value | vs Industry |
                |--------|-------|-------------|
                | Revenue | {fin.get('revenue', 'N/A')} | {fin.get('revenue_vs_industry', 'N/A')} |
                | Productivity | {fin.get('productivity', 'N/A')} | {fin.get('productivity_vs_industry', 'N/A')} |
                """)
                
                if fin.get("key_strength"):
                    st.info(f"💪 **Strength:** {fin.get('key_strength')}")
                if fin.get("key_concern") and fin.get("key_concern") != "None identified":
                    st.warning(f"⚠️ **Concern:** {fin.get('key_concern')}")
            
            with col_right:
                # Risk Assessment
                st.markdown("### 🛡️ Risk Assessment")
                risk = report.get("risk_assessment", {})
                
                overall_risk = risk.get("overall_risk", "Unknown")
                risk_emoji = {"Low": "🟢", "Medium": "🟡", "High": "🟠", "Critical": "🔴"}.get(overall_risk, "⚪")
                st.markdown(f"**Overall Risk:** {risk_emoji} **{overall_risk}** (Score: {risk.get('risk_score', 0)})")
                
                st.markdown(f"_{risk.get('explanation', '')}_")
                
                # Risk flags
                if risk.get("flags"):
                    st.markdown("**Detected Flags:**")
                    for flag in risk.get("flags", []):
                        st.markdown(f"- 🚩 {flag}")
                
                # Red flags from LLM
                if risk.get("red_flags"):
                    st.markdown("**Red Flags:**")
                    for rf in risk.get("red_flags", []):
                        st.markdown(f"- ❌ {rf}")
                
                # Mitigating factors
                if risk.get("mitigating_factors"):
                    st.markdown("**Mitigating Factors:**")
                    for mf in risk.get("mitigating_factors", []):
                        st.markdown(f"- ✅ {mf}")
                
                # Hierarchy Analysis
                st.markdown("### 🏛️ Hierarchy Analysis")
                hier = report.get("hierarchy_analysis", {})
                is_dm = "✅ Yes" if hier.get("is_decision_maker") else "❌ No"
                has_parent = "Yes" if hier.get("has_parent") else "No"
                st.markdown(f"""
                - **Decision Maker:** {is_dm}
                - **Entity Type:** {hier.get('entity_type', 'N/A')}
                - **Has Parent Company:** {has_parent}
                """)
            
            st.markdown("---")
            
            # Recommendation Section (Full Width)
            st.markdown("### 🎯 Recommendation")
            rec = report.get("recommendation", {})
            
            rec_cols = st.columns(4)
            with rec_cols[0]:
                st.metric("Verdict", rec.get("verdict", "N/A"))
            with rec_cols[1]:
                st.metric("Timeline", rec.get("timeline", "N/A"))
            with rec_cols[2]:
                st.metric("Confidence", rec.get("confidence", "N/A"))
            with rec_cols[3]:
                if st.button("🗑️ Clear Report"):
                    st.session_state.dd_report = None
                    st.rerun()
            
            if rec.get("action"):
                st.info(f"📌 **Recommended Action:** {rec.get('action')}")

# ============== PAGE: MARKET ENTRY ADVISOR ==============
elif page == "🌏 Market Entry":
    st.markdown('<h1 class="main-header">🌏 Market Entry Advisor</h1>', unsafe_allow_html=True)
    
    st.markdown("""
    **Business Use Case:** Planning expansion into new markets? Get data-driven recommendations 
    on which markets to prioritize and a list of top target companies.
    """)
    
    # Initialize session state
    if "market_results" not in st.session_state:
        st.session_state.market_results = None
    if "market_advice" not in st.session_state:
        st.session_state.market_advice = None
    
    # Two input modes
    tab_nlp, tab_form = st.tabs(["💬 Ask AI", "📝 Use Filters"])
    
    with tab_nlp:
        st.markdown("### 💬 Natural Language Query")
        st.markdown("_Example: 'Find fintech companies in Singapore with revenue over $5M'_")
        
        user_query = st.text_area(
            "Describe what you're looking for:",
            placeholder="I want to find manufacturing companies in Southeast Asia with more than 100 employees...",
            height=100,
            key="nlp_query"
        )
        
        
        if st.button("🔍 Search with AI", type="primary", key="nlp_search"):
            if user_query and llm and llm.enabled:
                with st.spinner("Parsing your query..."):
                    parsed = llm.parse_market_query(user_query)
                    if parsed.get("parsed"):
                        st.session_state.market_filters = parsed.get("filters", {})
                        st.success(f"✅ Analysis Ready! Scroll down to see results.")
                    else:
                        st.error(f"Could not parse query: {parsed.get('error')}")
            elif not llm or not llm.enabled:
                st.warning("LLM not enabled. Please use the Filters tab instead.")
    
    with tab_form:
        st.markdown("### 📝 Filter Companies")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Region filter
            regions = ['All'] + sorted(results_df['Region'].dropna().unique().tolist())
            form_region = st.selectbox("🌍 Region", regions, key="form_region")
            
            # Country filter
            if form_region != 'All':
                countries = ['All'] + sorted(results_df[results_df['Region'] == form_region]['Country'].dropna().unique().tolist())
            else:
                countries = ['All'] + sorted(results_df['Country'].dropna().unique().tolist())
            form_country = st.selectbox("🏳️ Country", countries, key="form_country")
            
            # Industry filter
            industries = ['All'] + sorted(results_df['SIC Description'].dropna().unique().tolist())[:50]
            form_industry = st.selectbox("🏭 Industry", industries, key="form_industry")
        
        with col2:
            # Revenue range
            form_min_rev = st.number_input("💰 Min Revenue (USD)", min_value=0, value=0, step=100000, key="form_min_rev")
            form_max_rev = st.number_input("💰 Max Revenue (USD)", min_value=0, value=0, step=1000000, key="form_max_rev", help="0 = no limit")
            
            # Tier filter
            form_tiers = st.multiselect("🎯 Target Tiers", [1, 2, 3, 4, 5], default=[1, 2, 3], key="form_tiers")
            
            # Risk filter
            form_exclude_risk = st.checkbox("🛡️ Exclude High-Risk Entities", value=True, key="form_exclude_risk")
        
        if st.button("🎯 Apply Filters", type="primary", key="form_search"):
            st.session_state.market_filters = {
                "region": form_region if form_region != 'All' else None,
                "country": form_country if form_country != 'All' else None,
                "industry_keywords": [form_industry] if form_industry != 'All' else [],
                "min_revenue": form_min_rev if form_min_rev > 0 else None,
                "max_revenue": form_max_rev if form_max_rev > 0 else None,
                "target_tiers": form_tiers,
                "exclude_high_risk": form_exclude_risk
            }
    
    # Process filters and show results
    if "market_filters" in st.session_state and st.session_state.market_filters:
        filters = st.session_state.market_filters
        
        st.markdown("---")
        st.markdown("### 📊 Market Analysis Results")
        
        # Display active filters friendly UI
        st.markdown("##### 🎯 Active Filters:")
        tags = []
        if filters.get("region"): tags.append(f"🌍 Region: {filters['region']}")
        if filters.get("country"): tags.append(f"🏳️ Country: {filters['country']}")
        if filters.get("industry_keywords"): tags.append(f"🏭 Industry: {', '.join(filters['industry_keywords'])}")
        if filters.get("min_revenue"): tags.append(f"💰 Min Rev: ${filters['min_revenue']:,.0f}")
        
        # Display tags
        st.markdown(" ".join([f"`{t}`" for t in tags]))
        
        # Apply filters to dataframe
        market_df = results_df.copy()
        
        # 1. Region Filter (Exact match on existing values)
        if filters.get("region"):
            # Only apply if the region exists in data, otherwise ignore (assume LLM hallucinated 'East Asia')
            if filters["region"] in market_df['Region'].unique():
                market_df = market_df[market_df['Region'] == filters["region"]]
        
        # 2. Country Filter (Fuzzy match)
        if filters.get("country"):
            target_country = filters["country"].strip().lower()
            # fuzzy matching: remove special chars, spaces
            market_df['Country_Norm'] = market_df['Country'].astype(str).str.lower().str.strip()
            # Check for exact contain
            market_df = market_df[market_df['Country_Norm'].str.contains(target_country, regex=False)]
            
        # 3. Industry Filter (Keywords OR logic)
        if filters.get("industry_keywords") and isinstance(filters["industry_keywords"], list):
            keywords = filters["industry_keywords"]
            # Construct OR regex: keyword1|keyword2|keyword3
            if keywords:
                pattern = '|'.join([k for k in keywords if k])
                market_df = market_df[market_df['SIC Description'].str.contains(pattern, case=False, na=False)]
                
        if filters.get("min_revenue"):
            market_df = market_df[market_df['Revenue_USD_Clean'] >= filters["min_revenue"]]
        if filters.get("max_revenue"):
            market_df = market_df[market_df['Revenue_USD_Clean'] <= filters["max_revenue"]]
        if filters.get("target_tiers"):
            market_df = market_df[market_df['Cluster'].isin(filters["target_tiers"])]
        if filters.get("exclude_high_risk") and 'Risk_Flags' in market_df.columns:
            market_df = market_df[market_df['Risk_Flags'] < 2]
        
        # Show summary metrics
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("🏢 Companies Found", f"{len(market_df):,}")
        with col2:
            if len(market_df) > 0:
                st.metric("💰 Median Revenue", f"${market_df['Revenue_USD_Clean'].median():,.0f}")
        with col3:
            if len(market_df) > 0 and 'Lead_Score' in market_df.columns:
                st.metric("⭐ Avg Lead Score", f"{market_df['Lead_Score'].mean():.1f}")
        with col4:
            countries_count = market_df['Country'].nunique()
            st.metric("🌍 Countries", countries_count)
        
        if len(market_df) > 0:
            # Market breakdown by country
            st.markdown("#### 🗺️ Market Breakdown by Country")
            country_stats = market_df.groupby('Country').agg({
                'DUNS Number ': 'count',
                'Revenue_USD_Clean': 'median',
                'Lead_Score': 'mean' if 'Lead_Score' in market_df.columns else 'count'
            }).reset_index()
            country_stats.columns = ['Country', 'Companies', 'Median Revenue', 'Avg Lead Score']
            country_stats = country_stats.sort_values('Companies', ascending=False).head(10)
            
            st.dataframe(country_stats, use_container_width=True)
            
            # Top prospects table
            st.markdown("#### 🏆 Top Target Companies")
            
            col_n, _ = st.columns([1, 4])
            with col_n:
                top_n = st.number_input("Show Top N:", min_value=10, max_value=1000, value=50, step=10)
            
            display_cols = ['Company Sites', 'Country', 'SIC Description', 'Revenue_USD_Clean', 'Employees_Total_Clean', 'Lead_Score', 'Cluster_Name']
            available_cols = [c for c in display_cols if c in market_df.columns]
            
            if 'Lead_Score' in market_df.columns:
                top_companies = market_df.nlargest(top_n, 'Lead_Score')[available_cols]
            else:
                top_companies = market_df.nlargest(top_n, 'Revenue_USD_Clean')[available_cols]
            
            st.dataframe(top_companies, use_container_width=True)
            
            # AI Strategy Recommendation
            st.markdown("---")
            if st.button("🧠 Generate AI Strategy Recommendation", type="primary"):
                if llm and llm.enabled:
                    with st.spinner("Generating market entry strategy..."):
                        market_stats = {
                            "total_companies": len(market_df),
                            "countries": country_stats.to_dict('records'),
                            "median_revenue": market_df['Revenue_USD_Clean'].median(),
                            "avg_lead_score": market_df['Lead_Score'].mean() if 'Lead_Score' in market_df.columns else 0,
                            "top_industries": market_df['SIC Description'].value_counts().head(5).to_dict(),
                            "filters_applied": filters
                        }
                        advice = llm.generate_market_entry_advice(market_stats, str(filters))
                        st.session_state.market_advice = advice
                else:
                    st.warning("LLM not enabled. Set GEMINI_API_KEY for AI recommendations.")
            
            if st.session_state.market_advice:
                st.markdown("#### 🎯 AI Strategy Recommendation")
                st.info(st.session_state.market_advice)
        else:
            st.warning("No companies match your criteria. Try adjusting the filters.")
        
        # Clear button
        if st.button("🗑️ Clear Results"):
            st.session_state.market_filters = None
            st.session_state.market_results = None
            st.session_state.market_advice = None
            st.rerun()

# ============== PAGE: COMPANY EXPLORER ==============
elif page == "🔍 Company Explorer":
    st.markdown('<h1 class="main-header">🔍 Company Explorer</h1>', unsafe_allow_html=True)
    
    # Search box
    search_query = st.text_input("🔎 Search Companies", placeholder="Enter company name...")
    
    if search_query:
        search_df = filtered_df[filtered_df['Company Sites'].str.contains(search_query, case=False, na=False)]
    else:
        search_df = filtered_df
    
    # Pagination settings
    items_per_page = 50
    total_items = len(search_df)
    total_pages = max(1, (total_items - 1) // items_per_page + 1)
    
    # Pagination Controls
    col1, col2 = st.columns([1, 4])
    with col1:
        current_page = st.number_input("Pages", min_value=1, max_value=total_pages, value=1, step=1)
    
    start_idx = (current_page - 1) * items_per_page
    end_idx = start_idx + items_per_page
    
    st.markdown(f"**Showing {start_idx+1}-{min(end_idx, total_items)} of {total_items:,} companies**")
    
    # Display table
    display_cols = ['Company Sites', 'Country', 'SIC Description', 'Employees_Total_Clean', 'Revenue_USD_Clean', 'Cluster_Name', 'Anomaly_Label']
    st.dataframe(
        search_df[display_cols].iloc[start_idx:end_idx],
        use_container_width=True,
        height=400
    )
    
    # Company detail view
    st.markdown("---")
    st.markdown("### 📋 Company Detail View")
    
    # Use all unique companies for sorting but limit if too huge? 
    # Streamlit selectbox handles thousands generally fine, but let's be safe.
    company_list = search_df['Company Sites'].dropna().unique().tolist()
    if len(company_list) > 10000:
        st.warning("Too many companies to list. Please use the search bar to filter.")
        company_list = company_list[:10000]
    else:
        company_list = sorted(company_list)
    if company_list:
        selected_company = st.selectbox("Select a company for detailed view", company_list)
        
        if selected_company:
            company_data = search_df[search_df['Company Sites'] == selected_company].iloc[0]
            
            col1, col2 = st.columns(2)
            with col1:
                st.markdown("#### 📌 Basic Info")
                st.markdown(f"**Company:** {company_data['Company Sites']}")
                st.markdown(f"**Country:** {company_data['Country']}")
                st.markdown(f"**Industry:** {company_data['SIC Description']}")
                st.markdown(f"**Employees:** {company_data['Employees_Total_Clean']:,.0f}")
                st.markdown(f"**Revenue:** ${company_data['Revenue_USD_Clean']:,.0f}")
                st.markdown(f"**Age:** {company_data.get('Company_Age', 'N/A')} years")
                st.markdown(f"**Market Value:** ${company_data.get('Market_Value_Clean', 0):,.0f}")
                st.markdown(f"**IT Spend:** ${company_data.get('IT_Spend_Clean', 0):,.0f}")
                is_domestic = "Yes" if company_data.get('Is_Domestic_Ultimate_Clean', 0) == 1 else "No"
                st.markdown(f"**Domestic Ultimate:** {is_domestic}")
            
            with col2:
                st.markdown("#### 🏷️ Segmentation")
                cluster_name = company_data['Cluster_Name']
                anomaly_status = company_data['Anomaly_Label']
                
                st.markdown(f"**Cluster:** {cluster_name}")
                if anomaly_status == 'Anomaly':
                    st.markdown("**Status:** <span class='anomaly-badge'>⚠️ Anomaly</span>", unsafe_allow_html=True)
                else:
                    st.markdown("**Status:** <span class='normal-badge'>✓ Normal</span>", unsafe_allow_html=True)
            
            # Link to Due Diligence
            st.markdown("---")
            st.info("💡 **Tip:** For a comprehensive AI-powered analysis, visit the **📋 Due Diligence** page from the sidebar.")

# ============== PAGE: CLUSTER ANALYSIS ==============
elif page == "📈 Cluster Analysis":
    st.markdown('<h1 class="main-header">📈 Cluster Analysis</h1>', unsafe_allow_html=True)
    
    # Cluster profiles
    cluster_profiles = results_df.groupby('Cluster_Name').agg({
        'DUNS Number ': 'count',
        'Revenue_USD_Clean': 'median',
        'Employees_Total_Clean': 'median',
        'Region': lambda x: x.mode().iloc[0] if len(x.mode()) > 0 else 'N/A',
        'SIC Description': lambda x: x.mode().iloc[0] if len(x.mode()) > 0 else 'N/A'
    }).reset_index()
    cluster_profiles.columns = ['Cluster', 'Size', 'Median_Revenue', 'Median_Employees', 'Top_Region', 'Top_Industry']
    cluster_profiles['Percentage'] = (cluster_profiles['Size'] / cluster_profiles['Size'].sum() * 100).round(1).astype(str) + '%'
    
    st.markdown("### 📊 Cluster Profiles")
    st.dataframe(cluster_profiles, use_container_width=True)
    
    # Visual comparison
    st.markdown("### 📉 Cluster Comparison")
    
    col1, col2 = st.columns(2)
    with col1:
        fig = px.bar(
            cluster_profiles,
            x='Cluster',
            y='Median_Revenue',
            title='Median Revenue by Cluster',
            color='Cluster',
            color_discrete_sequence=px.colors.qualitative.Set2,
            labels={'Cluster': 'Cluster', 'Median_Revenue': 'Median Revenue (USD)'}
        )
        fig.update_layout(
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            font=dict(color='white'),
            showlegend=False
        )
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        fig = px.bar(
            cluster_profiles,
            x='Cluster',
            y='Median_Employees',
            title='Median Employees by Cluster',
            color='Cluster',
            color_discrete_sequence=px.colors.qualitative.Set2,
            labels={'Cluster': 'Cluster', 'Median_Employees': 'Median Employees'}
        )
        fig.update_layout(
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            font=dict(color='white'),
            showlegend=False
        )
        st.plotly_chart(fig, use_container_width=True)
    
    # LLM Cluster Insights
    st.markdown("---")
    st.markdown("### 🤖 AI-Powered Cluster Insights")
    
    selected_cluster_for_insight = st.selectbox("Select Cluster for AI Analysis", cluster_profiles['Cluster'].tolist())
    
    if st.button("🧠 Generate Cluster Persona", key="cluster_persona"):
        if llm and llm.enabled:
            with st.spinner("Generating cluster insight..."):
                profile = cluster_profiles[cluster_profiles['Cluster'] == selected_cluster_for_insight].iloc[0].to_dict()
                insight = llm.generate_cluster_insight(
                    cluster_id=selected_cluster_for_insight,
                    profile={
                        'Size': profile['Size'],
                        'Percentage': profile['Percentage'],
                        'Median_Revenue_USD': profile['Median_Revenue'],
                        'Median_Employees': profile['Median_Employees'],
                        'Top_Region': profile['Top_Region'],
                        'Top_Industry': profile['Top_Industry'],
                        'Top_Entity_Type': 'Mixed'
                    }
                )
                st.markdown(insight)
        else:
            st.warning("LLM is not enabled. Set GEMINI_API_KEY environment variable.")

# ============== PAGE: RISK DETECTION ==============
elif page == "⚠️ Risk Detection":
    st.markdown('<h1 class="main-header">⚠️ Risk Detection</h1>', unsafe_allow_html=True)
    
    st.markdown("""
    **Business Use Case:** Identify high-risk entities for due diligence, compliance checks, 
    and data quality verification before business engagement.
    """)
    
    # Risk metrics
    col1, col2, col3, col4 = st.columns(4)
    
    has_risk_cols = 'Risk_Shell' in results_df.columns
    
    if has_risk_cols:
        with col1:
            shell_risk = results_df['Risk_Shell'].sum()
            st.metric("🏚️ Shell Company Risk", f"{shell_risk:,}", help="High revenue, zero employees")
        with col2:
            anomalies = (results_df['Anomaly_Label'] == 'Anomaly').sum()
            st.metric("📊 Statistical Anomaly", f"{anomalies:,}", help="Isolation Forest detected")
        with col3:
            high_risk = (results_df['Risk_Flags'] >= 2).sum()
            st.metric("🚨 High-Risk Entities", f"{high_risk:,}", help="2+ risk flags")
        with col4:
            pct_risk = (results_df['Risk_Flags'] > 0).sum() / len(results_df) * 100
            st.metric("📈 Risk Rate", f"{pct_risk:.1f}%")
    else:
        anomalies = (results_df['Anomaly_Label'] == 'Anomaly').sum()
        st.metric("📊 Anomalies Detected", f"{anomalies:,}")
    
    st.markdown("---")
    
    # Risk type breakdown
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### 🏚️ Shell Company Risk")
        st.markdown("Companies with high revenue but zero employees - potential holding companies or data issues.")
        if has_risk_cols:
            shell_df = results_df[results_df['Risk_Shell'] == True].nlargest(20, 'Revenue_USD_Clean')
            if len(shell_df) > 0:
                st.dataframe(
                    shell_df[['Company Sites', 'Revenue_USD_Clean', 'Employees_Total_Clean', 'SIC Description']].head(10),
                    use_container_width=True
                )
            else:
                st.info("No shell company risks detected.")
    
    with col2:
        st.markdown("### 📊 Statistical Anomalies")
        st.markdown("Companies with unusual patterns detected by Isolation Forest algorithm.")
        anomalies_df = results_df[results_df['Anomaly_Label'] == 'Anomaly'].nlargest(20, 'Revenue_USD_Clean')
        if len(anomalies_df) > 0:
            st.dataframe(
                anomalies_df[['Company Sites', 'Revenue_USD_Clean', 'Employees_Total_Clean', 'Cluster_Name']].head(10),
                use_container_width=True
            )
    
    st.markdown("---")
    
    # AI Investigation
    st.markdown("### 🕵️ AI Risk Investigation")
    
    risk_df = results_df[results_df['Anomaly_Label'] == 'Anomaly'].copy()
    anomaly_list = risk_df['Company Sites'].dropna().head(20).tolist()
    if anomaly_list:
        selected_anomaly = st.selectbox("Select entity to investigate", anomaly_list)
        
        if st.button("🔍 Investigate with AI", key="investigate_risk"):
            if llm and llm.enabled:
                with st.spinner("Analyzing risk..."):
                    anomaly_data = risk_df[risk_df['Company Sites'] == selected_anomaly].iloc[0]
                    cluster_avg = results_df[results_df['Cluster_Name'] == anomaly_data['Cluster_Name']][['Revenue_USD_Clean', 'Employees_Total_Clean']].mean()
                    insight = llm.explain_anomaly(anomaly_data, cluster_avg)
                    st.markdown(insight)
            else:
                st.warning("LLM is not enabled. Set GEMINI_API_KEY environment variable.")

# ============== PAGE: COMPANY COMPARISON ==============
elif page == "⚖️ Company Comparison":
    st.markdown('<h1 class="main-header">⚖️ Company Comparison</h1>', unsafe_allow_html=True)
    
    st.markdown("Select two companies to compare their profiles and get AI-powered competitive analysis.")
    
    col1, col2 = st.columns(2)
    
    company_list = filtered_df['Company Sites'].dropna().unique().tolist()[:500]
    
    with col1:
        st.markdown("### 🏢 Company A")
        company_a = st.selectbox("Select Company A", company_list, key="comp_a")
        if company_a:
            data_a = filtered_df[filtered_df['Company Sites'] == company_a].iloc[0]
            st.markdown(f"**Industry:** {data_a['SIC Description']}")
            st.markdown(f"**Employees:** {data_a['Employees_Total_Clean']:,.0f}")
            st.markdown(f"**Revenue:** ${data_a['Revenue_USD_Clean']:,.0f}")
            st.markdown(f"**Cluster:** {data_a['Cluster_Name']}")
    
    with col2:
        st.markdown("### 🏢 Company B")
        remaining_companies = [c for c in company_list if c != company_a]
        company_b = st.selectbox("Select Company B", remaining_companies, key="comp_b")
        if company_b:
            data_b = filtered_df[filtered_df['Company Sites'] == company_b].iloc[0]
            st.markdown(f"**Industry:** {data_b['SIC Description']}")
            st.markdown(f"**Employees:** {data_b['Employees_Total_Clean']:,.0f}")
            st.markdown(f"**Revenue:** ${data_b['Revenue_USD_Clean']:,.0f}")
            st.markdown(f"**Cluster:** {data_b['Cluster_Name']}")
    
    if company_a and company_b:
        # Visual comparison
        st.markdown("---")
        st.markdown("### 📊 Quick Comparison")
        
        comparison_data = pd.DataFrame({
            'Metric': ['Employees', 'Revenue (USD)'],
            'Company A': [data_a['Employees_Total_Clean'], data_a['Revenue_USD_Clean']],
            'Company B': [data_b['Employees_Total_Clean'], data_b['Revenue_USD_Clean']]
        })
        
        fig = go.Figure()
        fig.add_trace(go.Bar(name='Company A', x=comparison_data['Metric'], y=comparison_data['Company A'], marker_color='#667eea'))
        fig.add_trace(go.Bar(name='Company B', x=comparison_data['Metric'], y=comparison_data['Company B'], marker_color='#764ba2'))
        fig.update_layout(
            barmode='group',
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            font=dict(color='white')
        )
        st.plotly_chart(fig, use_container_width=True)
        
        # AI Comparison
        st.markdown("---")
        if st.button("🤖 Generate AI Competitive Analysis", key="compare_ai"):
            if llm and llm.enabled:
                with st.spinner("Generating competitive analysis..."):
                    insight = llm.compare_companies(data_a, data_b)
                    st.markdown("### 🧠 AI Competitive Analysis")
                    st.markdown(insight)
            else:
                st.warning("LLM is not enabled. Set GEMINI_API_KEY environment variable.")

# ============== PAGE: SIMULATOR ==============
elif page == "🚀 New Company Simulator":
    st.markdown('<h1 class="main-header">🚀 New Company Simulator</h1>', unsafe_allow_html=True)
    
    # --- 1. Initialize Session State ---
    # Ensure that even if the user switches pages or triggers a rerun, the results will not be lost
    if "sim_data_ready" not in st.session_state:
        st.session_state.sim_data_ready = False
    if "sim_prediction" not in st.session_state:
        st.session_state.sim_prediction = None
    if "sim_action_report" not in st.session_state:
        st.session_state.sim_action_report = None

    st.markdown("""
    **Business Use Case:** Simulate a new market entrant or prospect to evaluate 
    potential fit and sales strategy.
    """)
    
    col_input, col_display = st.columns([1, 2])
    
    with col_input:
        st.markdown("### 📝 Company Parameters")
        with st.form("simulator_form"):
            sim_name = st.text_input("Company Name", "Future Tech Inc.")
            sim_rev = st.number_input("Annual Revenue (USD)", min_value=0.0, value=5000000.0)
            sim_emp = st.number_input("Total Employees", min_value=1.0, value=25.0)
            
            sim_year = st.number_input("Year Found", min_value=1800, max_value=2026, value=2015)
            sim_market_val = st.number_input("Market Value (USD)", min_value=0.0, value=0.0)
            sim_it_spend = st.number_input("IT Spend (USD)", min_value=0.0, value=0.0)
            
            industries = sorted(results_df['SIC Description'].dropna().unique().tolist())
            sim_ind = st.selectbox("Industry", industries)
            
            regions = sorted(results_df['Region'].dropna().unique().tolist())
            sim_region = st.selectbox("Region", regions)
            
            entity_types = ['Parent', 'Subsidiary', 'Branch', 'Headquarters'] 
            sim_entity = st.selectbox("Entity Type", entity_types)
            
            sim_domestic = st.checkbox("Is Domestic Ultimate?", value=False)
            
            submitted = st.form_submit_button("🚀 Analyze Strategy")

        if st.session_state.sim_data_ready:
            st.write("")
            if st.button("🗑️ Reset Simulator", use_container_width=True):
                st.session_state.sim_data_ready = False
                st.session_state.sim_prediction = None
                st.session_state.sim_action_report = None
                st.rerun()

        # --- 2. Handle Submission ---
        if submitted:
            if evaluator and evaluator.loaded:
                with st.spinner("Inference Engine running..."):
                    input_dict = {
                        "Name": sim_name, 
                        "Revenue (USD)": sim_rev,
                        "Employees Total": sim_emp, 
                        "SIC Description": sim_ind,
                        "Region": sim_region, 
                        "Entity Type": sim_entity,
                        "Year Found": sim_year,                
                        "Is Domestic Ultimate": sim_domestic,
                        "Market Value (USD)": sim_market_val,
                        "IT Spend": sim_it_spend
                    }
                    # Perform reasoning and store the state
                    st.session_state.sim_prediction = evaluator.predict(input_dict)
                    st.session_state.sim_data_ready = True
                    
                    # Execute LLM and store the state
                    if llm and llm.enabled:
                        try:
                            input_dict.update(st.session_state.sim_prediction)
                            st.session_state.sim_action_report = llm.generate_action_report(pd.Series(input_dict))
                        except Exception as e:
                            st.error(f"LLM Error: {e}")
                    
                    st.rerun()
            else:
                st.error("Inference Engine not loaded.")

    # --- 3. Display Region ---
    with col_display:
        if st.session_state.sim_data_ready:
            res = st.session_state.sim_prediction
            st.markdown("### 🎯 Strategic Analysis")
            
            # Indicator Display
            m1, m2, m3 = st.columns(3)
            with m1:
                st.metric("Predicted Cluster", res['Cluster'])
            with m2:
                st.metric("Lead Score", f"{res['Lead_Score']:.0f} ({res['Lead_Tier']})")
            with m3:
                status_color = "inverse" if res['Anomaly'] == 'Anomaly' else "normal"
                st.metric("Risk Status", res['Anomaly'], delta_color=status_color)
            
            st.markdown("---")
            
            # LLM Action Report Showcase
            if st.session_state.sim_action_report:
                report = st.session_state.sim_action_report
                st.markdown("#### ⚔️ AI Action Report")
                
                r1, r2 = st.columns(2)
                r3, r4 = st.columns(2) # 2x2 layout is more stable on mobile devices or narrow screens
                
                with r1: st.info(f"**Verdict:**\n\n{report.get('Verdict', 'N/A')}")
                with r2: st.success(f"**Action:**\n\n{report.get('Action', 'N/A')}")
                with r3: st.warning(f"**Reason:**\n\n{report.get('Reason', 'N/A')}")
                with r4: st.error(f"**Risk:**\n\n{report.get('Risk', 'N/A')}")
        else:
            st.info("👈 Enter company details and click 'Analyze Strategy' to see the magic.")

# Footer
st.markdown("---")
st.markdown(
    "<div style='text-align: center; color: #888;'>🏢 SDS Datathon 2026 - AI-Driven Company Intelligence Dashboard</div>",
    unsafe_allow_html=True
)
